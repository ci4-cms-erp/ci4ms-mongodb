<?php

return [
    'conf'=>'Configuration',
    'fin'=>'Finishing installation',

    'rootUsername'=>'Root Username',
    'rootUsernamePh'=>'',
    'rootUsernameDesc'=>'We gonna use once time. This input never will never be saved.',

    'rootPwd'=>'Root Password',
    'rootPwdPh'=>'',
    'rootPwdDesc'=>'We gonna use once time. This input never will never be saved.',

    'dbName'=>'Database Name',
    'dbNamePh'=>'',
    'dbNameDesc'=>'',

    'username'=>'Database Username',
    'usernamePh'=>'',
    'usernameDesc'=>'',

    'pwd'=>'Database Password',
    'pwdPh'=>'',
    'pwdDesc'=>'',

    'dbHost'=>'Database Host',
    'dbHostPh'=>'',
    'dbHostDesc'=>'',

    'dbPort'=>'Database Port',
    'dbPortPh'=>'',
    'dbPortDesc'=>'',

    'pre'=>'Table Prefix',
    'prePh'=>'',
    'preDesc'=>'',

    'title'=>'Site Title',
    'titlePh'=>'',
    'titleDesc'=>'',

    'adminU'=>'Username',
    'adminUPh'=>'',
    'adminUDesc'=>'',

    'adminPwd'=>'Password',
    'adminPwdPh'=>'',
    'adminPwdDesc'=>'',

    'email'=>'Your E-mail',
    'emailPh'=>'',
    'emailDesc'=>'',

    'sev'=>'Search Engine Visibility',
    'sevCb'=>'Do you want to block search engines ?',
    'sevDesc'=>'',

    'nextBtn'=>'Next',
    'sbmtBtn'=>'Submit',
    'preBtn'=>'Previous',
];
